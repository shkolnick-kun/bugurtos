This directory contains BuguRTOS (wich is licensed under GPLv3 with exception) source code and third party software (licensed under third party licenses).
