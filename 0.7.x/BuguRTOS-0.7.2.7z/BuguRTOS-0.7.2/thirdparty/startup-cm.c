/**************************************************************************
    Startup file for cortex-m0/3/4 microcontrollers.
    Copyright (C) 2014  anonimous

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Please contact with me by E-mail: shkolnick.kun@gmail.com

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes BuguRTOS, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
**************************************************************************/

#ifdef __cplusplus
extern "C"
{
    extern void __libc_init_array(void);
#endif //CPP

    extern int main(void);

    extern int __text_end__;
    extern int __data_beg__;
    extern int __data_end__;
    extern int __bss_beg__;
    extern int __bss_end__;

    extern int __stack_end__;
    //extern void (* const _vectors[])(void);

    static void Init_Data(void)
    {
        int * src = &__text_end__;
        int * dst = &__data_beg__;
        int len = &__data_end__ - &__data_beg__;
        //Copy .data
        while( len-- )
        {
            *dst++ = *src++;
        }
        len = &__bss_end__ - &__bss_beg__;
        dst = &__bss_beg__;
        //Clear .bss
        while( len-- )
        {
            *dst++ = 0;
        }
#ifdef __cplusplus
        __libc_init_array(void);
#endif //CPP
    }

    __attribute__ (( naked )) void Reset_Handler(void)
    {
        __asm__ __volatile__ ("mov sp, %0\n\t" : : "r" (&__stack_end__) ); // Set sp.
        Init_Data();
        main();
        while(1)
        {
        }
    }
//==================================================
    void Default_Handler(void)
    {
        while(1)
        {
        }
    }

#ifdef __cplusplus
}
#endif //CPP
